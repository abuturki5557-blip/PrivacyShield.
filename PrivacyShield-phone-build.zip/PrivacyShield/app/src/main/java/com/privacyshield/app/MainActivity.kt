package com.privacyshield.app

import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.text.InputType
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import java.util.Locale

class MainActivity : FragmentActivity() {
    private val prefs by lazy { getSharedPreferences("privacy_shield", MODE_PRIVATE) }
    private val selected = mutableSetOf<String>()
    // Keep "auto" as a setting; resolve the display language separately.
    private var languageSetting = "ar"
    private val uiLanguage: String
        get() = if (languageSetting == "auto") Locale.getDefault().language else languageSetting

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selected.addAll(prefs.getStringSet("protected_apps", emptySet()) ?: emptySet())
        languageSetting = prefs.getString("language", "ar") ?: "ar"
        if (isLauncherInvocation()) showLauncher() else showWeather()
    }

    private fun isLauncherInvocation(): Boolean = intent?.categories?.contains(Intent.CATEGORY_HOME) == true
    private fun isRtl() = uiLanguage == "ar" || uiLanguage == "ur"
    private fun tr(ar: String, en: String, fr: String = en, tu: String = en, ur: String = ar): String = when (uiLanguage) {
        "en" -> en; "fr" -> fr; "tr" -> tu; "ur" -> ur; else -> ar
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float = 18f, color: Int = Color.rgb(28, 45, 72)): TextView =
        TextView(this).apply { text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER; setPadding(dp(8), dp(8), dp(8), dp(8)) }

    private fun base(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(20), dp(24), dp(20), dp(20))
        setBackgroundColor(Color.rgb(224, 239, 255))
        layoutDirection = if (isRtl()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
    }

    private fun showWeather() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val root = base()
        val city = text(tr("الطقس المحلي", "Local Weather", "Météo locale", "Yerel Hava Durumu", "مقامی موسم"), 20f)
        city.setOnLongClickListener { askPin(); true }
        root.addView(city, LinearLayout.LayoutParams(-1, dp(65)))
        root.addView(text("☀", 76f, Color.rgb(239, 166, 36)), LinearLayout.LayoutParams(-1, dp(120)))
        root.addView(text(tr("طقس صافٍ", "Clear sky", "Ciel dégagé", "Açık hava", "صاف موسم"), 25f))
        root.addView(text("28°", 58f, Color.rgb(25, 55, 91)))
        root.addView(text(tr("صنعاء • عرض تجريبي", "Sana'a • Demo", "Sanaa • Démo", "Sana • Demo", "صنعاء • آزمائشی"), 15f))
        root.addView(text(tr("توقعات الأيام القادمة", "Upcoming forecast", "Prévisions", "Gelecek günler", "آنے والے دنوں کی پیش گوئی"), 18f))
        root.addView(text("☀   29°       ☁   26°       ☀   30°", 17f))
        root.addView(text(tr("اضغط مطولاً على عنوان المدينة للدخول", "Long-press the city title to open settings", "Appui long sur le titre pour ouvrir les réglages", "Ayarlar için şehir başlığına basılı tutun", "ترتیبات کے لیے شہر کے عنوان کو دیر تک دبائیں"), 13f, Color.DKGRAY))
        setContentView(root)
    }

    private fun askPin() {
        val lockUntil = prefs.getLong("pin_lock_until", 0L)
        val now = System.currentTimeMillis()
        if (now < lockUntil) {
            val seconds = ((lockUntil - now + 999L) / 1000L)
            Toast.makeText(this, tr("تم إيقاف المحاولات مؤقتاً. حاول بعد $seconds ثانية.", "Too many attempts. Try again in $seconds seconds.", "Trop de tentatives. Réessayez dans $seconds secondes.", "Çok fazla deneme. $seconds saniye sonra tekrar deneyin.", "زیادہ کوششیں۔ $seconds سیکنڈ بعد دوبارہ کوشش کریں۔"), Toast.LENGTH_LONG).show()
            return
        }
        val storedHash = prefs.getString("pin_hash", null)
        val storedSalt = prefs.getString("pin_salt", null)
        if (storedHash.isNullOrBlank() || storedSalt.isNullOrBlank()) {
            showPinEnrollment()
            return
        }
        val input = EditText(this).apply {
            hint = tr("أدخل الرمز السري", "Enter PIN", "Entrez le code", "PIN girin", "خفیہ کوڈ درج کریں")
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        val builder = AlertDialog.Builder(this)
            .setTitle(tr("الدخول إلى لوحة الحماية", "Privacy panel", "Panneau de confidentialité", "Gizlilik paneli", "رازداری پینل"))
            .setView(input)
            .setPositiveButton(tr("دخول", "Unlock", "Ouvrir", "Aç", "کھولیں")) { _, _ ->
                if (verifyPin(input.text.toString())) {
                    prefs.edit().putInt("pin_failed_attempts", 0).putLong("pin_lock_until", 0L).apply()
                    showPanel()
                } else {
                    val failures = prefs.getInt("pin_failed_attempts", 0) + 1
                    val editor = prefs.edit().putInt("pin_failed_attempts", failures)
                    if (failures >= 5) {
                        editor.putInt("pin_failed_attempts", 0)
                        editor.putLong("pin_lock_until", System.currentTimeMillis() + 30_000L)
                        Toast.makeText(this, tr("خمس محاولات خاطئة. تم إيقاف الدخول 30 ثانية.", "Five incorrect attempts. Locked for 30 seconds.", "Cinq erreurs. Verrouillé pendant 30 secondes.", "Beş yanlış deneme. 30 saniye kilitlendi.", "پانچ غلط کوششیں۔ 30 سیکنڈ کے لیے بند۔"), Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this, tr("الرمز غير صحيح ($failures/5)", "Incorrect PIN ($failures/5)", "Code incorrect ($failures/5)", "PIN yanlış ($failures/5)", "غلط کوڈ ($failures/5)"), Toast.LENGTH_SHORT).show()
                    }
                    editor.apply()
                }
            }
            .setNegativeButton(tr("إلغاء", "Cancel", "Annuler", "İptal", "منسوخ"), null)
        if (canAuthenticateBiometric()) {
            builder.setNeutralButton(tr("استخدام البصمة", "Use biometrics", "Utiliser la biométrie", "Biyometri kullan", "بائیومیٹرک استعمال کریں")) { _, _ -> authenticateBiometric() }
        }
        builder.show()
    }

    /** Require the current PIN before allowing a replacement PIN to be created. */
    private fun verifyBeforeChangingPin() {
        val input = EditText(this).apply {
            hint = tr("أدخل الرمز الحالي", "Enter current PIN", "Entrez le code actuel", "Mevcut PIN'i girin", "موجودہ کوڈ درج کریں")
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this)
            .setTitle(tr("تأكيد الهوية", "Verify identity", "Vérifier l’identité", "Kimliği doğrula", "شناخت کی تصدیق"))
            .setView(input)
            .setPositiveButton(tr("متابعة", "Continue", "Continuer", "Devam et", "جاری رکھیں")) { _, _ ->
                if (verifyPin(input.text.toString())) showPinEnrollment()
                else Toast.makeText(this, tr("الرمز الحالي غير صحيح", "Current PIN is incorrect", "Code actuel incorrect", "Mevcut PIN yanlış", "موجودہ کوڈ غلط ہے"), Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(tr("إلغاء", "Cancel", "Annuler", "İptal", "منسوخ"), null)
            .show()
    }

    private fun showPinEnrollment() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val first = EditText(this).apply { hint = tr("أنشئ رمزاً من 6 أرقام على الأقل", "Create a PIN (6+ digits)", "Créer un code (6 chiffres min.)", "PIN oluştur (en az 6 hane)", "کم از کم 6 ہندسوں کا کوڈ بنائیں"); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        val second = EditText(this).apply { hint = tr("أعد إدخال الرمز", "Confirm PIN", "Confirmer le code", "PIN'i doğrula", "کوڈ دوبارہ درج کریں"); inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        box.addView(first); box.addView(second)
        AlertDialog.Builder(this)
            .setTitle(tr("إنشاء رمز الحماية", "Create security PIN", "Créer le code de sécurité", "Güvenlik PIN'i oluştur", "سیکیورٹی کوڈ بنائیں"))
            .setMessage(tr("هذه أول مرة تدخل فيها. أنشئ رمزاً لا يعرفه غيرك.", "First setup: create a PIN only you know.", "Première configuration : créez un code personnel.", "İlk kurulum: yalnızca sizin bildiğiniz bir PIN oluşturun.", "پہلی بار: اپنا خفیہ کوڈ بنائیں۔"))
            .setView(box)
            .setPositiveButton(tr("حفظ", "Save", "Enregistrer", "Kaydet", "محفوظ کریں"), null)
            .setNegativeButton(tr("إلغاء", "Cancel", "Annuler", "İptal", "منسوخ"), null)
            .create().also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val a = first.text.toString(); val b = second.text.toString()
                        if (a.length < 6 || a.any { !it.isDigit() }) {
                            first.error = tr("استخدم 6 أرقام على الأقل", "Use at least 6 digits", "Utilisez au moins 6 chiffres", "En az 6 rakam kullanın", "کم از کم 6 ہندسے استعمال کریں")
                        } else if (a != b) {
                            second.error = tr("الرمزان غير متطابقين", "PINs do not match", "Les codes ne correspondent pas", "PIN'ler eşleşmiyor", "کوڈز مماثل نہیں ہیں")
                        } else {
                            savePin(a)
                            dialog.dismiss()
                            showPanel()
                        }
                    }
                }
                dialog.show()
            }
    }

    private fun savePin(value: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = derivePinHash(value, salt)
        prefs.edit()
            .putString("pin_salt", android.util.Base64.encodeToString(salt, android.util.Base64.NO_WRAP))
            .putString("pin_hash", android.util.Base64.encodeToString(hash, android.util.Base64.NO_WRAP))
            .putInt("pin_failed_attempts", 0)
            .putLong("pin_lock_until", 0L)
            .apply()
    }

    private fun verifyPin(value: String): Boolean {
        val saltText = prefs.getString("pin_salt", null) ?: return false
        val hashText = prefs.getString("pin_hash", null) ?: return false
        return try {
            val salt = android.util.Base64.decode(saltText, android.util.Base64.NO_WRAP)
            val expected = android.util.Base64.decode(hashText, android.util.Base64.NO_WRAP)
            java.security.MessageDigest.isEqual(expected, derivePinHash(value, salt))
        } catch (_: Exception) { false }
    }

    private fun derivePinHash(value: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(value.toCharArray(), salt, 150_000, 256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword() }
    }

    private fun canAuthenticateBiometric(): Boolean {
        val manager = BiometricManager.from(this)
        return manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL) == BiometricManager.BIOMETRIC_SUCCESS
    }

    private fun authenticateBiometric() {
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                showPanel()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                Toast.makeText(this@MainActivity, errString, Toast.LENGTH_SHORT).show()
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(tr("فتح لوحة الحماية", "Unlock Privacy Shield", "Déverrouiller", "Gizlilik Kalkanı'nı aç", "رازداری شیلڈ کھولیں"))
            .setSubtitle(tr("تحقق من هويتك", "Verify your identity", "Vérifiez votre identité", "Kimliğinizi doğrulayın", "اپنی شناخت کی تصدیق کریں"))
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build()
        prompt.authenticate(info)
    }

    private fun showPanel() {
        // Protect sensitive settings from screenshots and recent-app previews.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        val root = base(); root.setBackgroundColor(Color.rgb(246, 248, 252))
        root.addView(text(tr("لوحة الحماية", "Privacy Shield", "Bouclier de confidentialité", "Gizlilik Kalkanı", "رازداری شیلڈ"), 25f))
        addButton(root, tr("اختيار التطبيقات المراد إخفاؤها", "Choose apps to hide", "Choisir les applications à masquer", "Gizlenecek uygulamaları seç", "چھپانے کے لیے ایپس منتخب کریں")) { showApps() }
        addButton(root, tr("تغيير الرمز السري", "Change security PIN", "Changer le code", "Güvenlik PIN'ini değiştir", "سیکیورٹی کوڈ تبدیل کریں")) { verifyBeforeChangingPin() }
        addButton(root, tr("تعيين كمشغّل الشاشة الرئيسية", "Set as home launcher", "Définir comme lanceur d'accueil", "Ana ekran başlatıcısı yap", "ہوم لانچر مقرر کریں")) { openHomeSettings() }
        addButton(root, tr("فتح درج التطبيقات", "Open app drawer", "Ouvrir le tiroir", "Uygulama çekmecesini aç", "ایپ ڈراور کھولیں")) { showLauncher() }
        addButton(root, tr("لغة التطبيق", "App language", "Langue", "Uygulama dili", "ایپ کی زبان")) { showLanguages() }
        root.addView(text(tr("التطبيقات المحددة للإخفاء: ${selected.size}", "Apps selected to hide: ${selected.size}", "Applications à masquer : ${selected.size}", "Gizlenecek uygulama: ${selected.size}", "چھپانے کے لیے منتخب ایپس: ${selected.size}"), 16f))
        root.addView(text(tr("الإخفاء يعمل داخل مشغّل درع الخصوصية بعد تعيينه كمشغّل افتراضي. لا يحذف التطبيقات ولا يمنع الوصول إليها من إعدادات النظام.", "Hiding works inside Privacy Shield after it is set as the default launcher. It does not uninstall apps or block access through system settings.", "Le masquage fonctionne dans ce lanceur défini par défaut. Il ne désinstalle pas les applications.", "Gizleme, varsayılan başlatıcı seçildikten sonra bu başlatıcıda çalışır. Uygulamaları kaldırmaz.", "چھپانا اس لانچر میں کام کرتا ہے؛ ایپس حذف نہیں ہوتیں۔"), 13f, Color.DKGRAY))
        addButton(root, tr("العودة إلى الطقس", "Back to weather", "Retour à la météo", "Hava durumuna dön", "موسم پر واپس جائیں")) { showWeather() }
        setContentView(root)
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val b = Button(this).apply { text = label; setOnClickListener { action() } }
        parent.addView(b, LinearLayout.LayoutParams(-1, dp(54)))
    }

    private fun openHomeSettings() {
        try { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        Toast.makeText(this, tr("اختر درع الخصوصية كتطبيق الشاشة الرئيسية الافتراضي", "Choose Privacy Shield as the default home app", "Choisissez Privacy Shield comme lanceur par défaut", "Privacy Shield'i varsayılan başlatıcı seçin", "پرائیویسی شیلڈ کو ڈیفالٹ ہوم ایپ منتخب کریں"), Toast.LENGTH_LONG).show()
    }

    /** Custom launcher: protected packages are omitted from this app drawer. */
    private fun showLauncher() {
        window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(20), dp(12), dp(12)); setBackgroundColor(Color.rgb(245, 248, 252)) }
        root.addView(text(tr("تطبيقاتي", "My apps", "Mes applications", "Uygulamalarım", "میری ایپس"), 24f))
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val launchIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(launchIntent, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != packageName && !selected.contains(it.activityInfo.packageName) }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
        apps.forEach { info ->
            val pkg = info.activityInfo.packageName
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(6), dp(8), dp(6)) }
            val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(packageManager) as Drawable); layoutParams = LinearLayout.LayoutParams(dp(44), dp(44)) }
            val label = TextView(this).apply { text = info.loadLabel(packageManager); textSize = 17f; setTextColor(Color.DKGRAY); setPadding(dp(12), dp(8), dp(12), dp(8)); layoutParams = LinearLayout.LayoutParams(0, dp(54), 1f) }
            row.addView(icon); row.addView(label)
            row.setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(pkg)
                if (launch != null) startActivity(launch)
            }
            list.addView(row)
        }
        if (apps.isEmpty()) list.addView(text(tr("لا توجد تطبيقات ظاهرة. افتح لوحة الحماية لإدارة التطبيقات.", "No visible apps. Open the privacy panel to manage apps.", "Aucune application visible.", "Görünen uygulama yok.", "کوئی نظر آنے والی ایپ نہیں۔"), 15f))
        scroll.addView(list); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        addButton(root, tr("لوحة الحماية", "Privacy panel", "Panneau", "Gizlilik paneli", "رازداری پینل")) { askPin() }
        setContentView(root)
    }

    private fun showApps() {
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)) }
        list.addView(text(tr("حدد التطبيقات التي تريد إخفاءها في مشغّلنا", "Select apps to hide in our launcher", "Sélectionnez les applications à masquer", "Başlatıcıda gizlenecek uygulamaları seçin", "لانچر میں چھپانے کے لیے ایپس منتخب کریں"), 21f))
        list.addView(text(tr("التطبيقات المحددة لن تظهر في درج مشغّل درع الخصوصية فقط.", "Selected apps are hidden only from the Privacy Shield app drawer.", "Les applications sélectionnées sont masquées uniquement dans ce tiroir.", "Seçilen uygulamalar yalnızca Privacy Shield çekmecesinde gizlenir.", "منتخب ایپس صرف اسی لانچر کی فہرست سے چھپیں گی۔"), 13f, Color.DKGRAY))
        apps.forEach { info ->
            val pkg = info.activityInfo.packageName
            val cb = CheckBox(this).apply {
                text = info.loadLabel(packageManager).toString(); isChecked = selected.contains(pkg); textSize = 17f
                setOnCheckedChangeListener { _, checked -> if (checked) selected.add(pkg) else selected.remove(pkg) }
            }
            list.addView(cb)
        }
        val save = Button(this).apply { text = tr("حفظ الاختيارات", "Save selection", "Enregistrer", "Seçimi kaydet", "انتخاب محفوظ کریں")
            setOnClickListener { prefs.edit().putStringSet("protected_apps", selected.toSet()).apply(); showPanel() } }
        list.addView(save); scroll.addView(list); setContentView(scroll)
    }

    private fun showLanguages() {
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        val labels = arrayOf("العربية", "English", "Français", "Türkçe", "اردو", tr("تلقائي حسب لغة الهاتف", "Automatic (phone language)", "Automatique (langue du téléphone)", "Otomatik (telefon dili)", "فون کی زبان کے مطابق"))
        val codes = arrayOf("ar", "en", "fr", "tr", "ur", "auto")
        AlertDialog.Builder(this).setTitle(tr("اختر اللغة", "Choose language", "Choisir la langue", "Dil seçin", "زبان منتخب کریں"))
            .setSingleChoiceItems(labels, codes.indexOf(languageSetting)) { dialog, which ->
                languageSetting = codes[which]
                prefs.edit().putString("language", languageSetting).apply()
                dialog.dismiss(); showPanel()
            }.setNegativeButton(tr("إلغاء", "Cancel", "Annuler", "İptal", "منسوخ"), null).show()
    }
}
